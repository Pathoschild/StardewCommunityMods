Adjusts the game clock speed by a configurable amount.  Speed up or slow down time.  Compatible with FreezeInside.

Configure by setting DayTime to your desired day length in seconds.  The base day is 7 seconds.  The default for the mod is 14 seconds.  Setting DayLength to lower than 7 seconds will not make time go faster.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust with technical help from Zoryn.

v1.4.2
Fixed bug if user upgraded dll from 1.2 without upgrading INI

v1.4.1
Fixed incorrect file path breaking function if INI is in Stardew Valley\Mods rather than %appdata%.

v1.4
Added new config option ChangeTimeSpeedOnFestivalDays, defaulted to false, due to reports that this mod messes up festival days.  Not convinced, but this will allow further testing.