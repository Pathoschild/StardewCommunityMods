Slows the game clock speed down by a configurable amount.  Cannot speed up time, however.  Will recognize if FreezeInside is installed and adjust behavior to accommodate.

Configure by setting DayTime to your desired time length in seconds.  The base day is 7 seconds.  The default for the mod is 14 seconds.  Setting DayLength to lower than 7 seconds will not make time go faster.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust.