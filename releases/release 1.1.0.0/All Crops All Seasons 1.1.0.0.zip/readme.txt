Allows all crops to be grown in all seasons, including winter.
By cantorsdust.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

There is one folder in this .zip.  The All Crops All Seasons folder must be placed in %appdata%\StardewValley\Mods.

Thus, the total path for both of the two files required for this mod to function are:
%appdata%\StardewValley\Mods\All Crops All Seasons\All Crops All Seasons.dll

AND

%appdata%\StardewValley\Mods\All Crops All Seasons\manifest.json


REQUIRES Storm to be installed!
http://storm.handsomematt.co.uk/builds/


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
USAGE
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Run StormLoader.exe in your main Stardew Valley folder.  This will load the mods and then start the game.
You will find that you can plant any crop in any season, harvest them in any season, and not lose them on season change.
This mod does NOT change store inventories, so you can only purchase crop seeds during their usual seasons.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CHANGELOG
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
v1.1.0.0
Port to Storm.  No longer requires XNB component.

v1.0
Initial release.