Allows Legendary Fish to be caught again and again.  Will prevent the achievement for catching all 5 legendary fish, unfortunately.
By cantorsdust.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

There is one folder in this .zip.  The All Crops All Seasons folder must be placed in %appdata%\StardewValley\Mods.

Thus, the total path for both of the two files required for this mod to function are:
%appdata%\StardewValley\Mods\RecatchLegendaryFish\RecatchLegendaryFish.dll

AND

%appdata%\StardewValley\Mods\RecatchLegendaryFish\manifest.json


REQUIRES Storm to be installed!
http://storm.handsomematt.co.uk/builds/


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
USAGE
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Run StormLoader.exe in your main Stardew Valley folder.  This will load the mods and then start the game.
You will find that you can catch the legendary fish as many times as desired.  Due to the target of the mod's code, this will unfortunately disable the achievement for catching all 5.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CHANGELOG
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
v1.0
Initial release.