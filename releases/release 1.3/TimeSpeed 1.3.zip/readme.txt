Adjusts the game clock speed by a configurable amount.  Speed up or slow down time.  Compatible with FreezeInside.

Configure by setting DayTime to your desired day length in seconds.  The base day is 7 seconds.  The default for the mod is 14 seconds.  Setting DayLength to lower than 7 seconds will not make time go faster.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust with technical help from Zoryn.

v1.3
Updated for SMAPI 0.37.  Not compatible with SMAPI 0.35 or 0.36.